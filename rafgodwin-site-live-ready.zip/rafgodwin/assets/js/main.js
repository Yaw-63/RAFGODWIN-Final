(function(){
'use strict';
var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
var root=document.documentElement;

/* ---- Terms of Service gate ---- */
var gate=$('#tos-gate'),blocked=$('#tos-blocked');
function store(v){try{localStorage.setItem('rg_tos',v)}catch(e){}}
function accepted(){try{return localStorage.getItem('rg_tos')==='accepted'}catch(e){return false}}
function unlock(){root.classList.remove('tos-lock');gate.hidden=true;blocked.hidden=true;gate.classList.remove('over');document.body.style.overflow=''}
function showGate(view){gate.hidden=false;blocked.hidden=true;gate.classList.toggle('over',!!view);$('#tos-accept').hidden=$('#tos-decline').hidden=!!view;$('#tos-close').hidden=!view;var b=$('#tos-accept');if(!view&&b)b.focus()}
function deny(){try{sessionStorage.setItem('rg_tos_declined','1')}catch(e){}store('declined');['.topbar','header.site','main','footer.site','.fab'].forEach(function(s){$$(s).forEach(function(n){n.remove()})});gate.hidden=true;blocked.hidden=false}
if(gate){
 if(accepted()){unlock()}else{root.classList.add('tos-lock');var d=false;try{d=localStorage.getItem('rg_tos')==='declined'}catch(e){}if(d)deny();else showGate(false)}
 $('#tos-accept').onclick=function(){store('accepted');unlock()};
 $('#tos-decline').onclick=deny;
 $('#tos-again').onclick=function(){store('');location.reload()};
 $('#tos-close').onclick=function(){gate.hidden=true};
 $$('.tos-open').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();showGate(true)})});
}

/* ---- mobile menu ---- */
var b=$('.burger'),m=$('.menu');
if(b&&m){b.addEventListener('click',function(){var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
$$('.menu a').forEach(function(a){a.addEventListener('click',function(){m.classList.remove('open')})})}

/* ---- reveal ---- */
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});$$('.reveal').forEach(function(el){io.observe(el)})}else{$$('.reveal').forEach(function(el){el.classList.add('in')})}

/* ---- portfolio filter ---- */
var fb=$$('.filters button');
fb.forEach(function(x){x.addEventListener('click',function(){fb.forEach(function(y){y.classList.remove('on')});x.classList.add('on');var f=x.dataset.f;$$('.shot').forEach(function(s){s.classList.toggle('hide',f!=='all'&&s.dataset.c!==f)})})});

/* ---- forms: WhatsApp or email copy ---- */
var WA=window.RG_WA||'233551120109',MAIL=window.RG_EMAIL||'info@rafgodwin.com';
$$('form.f').forEach(function(f){
 var msg=$('.msg',f),bar=$('.progress i',f),via='wa';
 $$('button[type=submit]',f).forEach(function(bt){bt.addEventListener('click',function(){via=bt.dataset.via})});
 function prog(){if(!bar)return;var r=$$('[required]',f),n=r.filter(function(x){return x.value.trim()}).length;bar.style.width=Math.round(n/r.length*100)+'%'}
 f.addEventListener('input',prog);prog();
 function say(html){msg.innerHTML=html;msg.classList.add('show');msg.scrollIntoView({behavior:'smooth',block:'nearest'})}
 f.addEventListener('submit',function(e){
  e.preventDefault();
  if(e.submitter&&e.submitter.dataset.via)via=e.submitter.dataset.via;
  var ok=true;
  $$('[required]',f).forEach(function(x){var w=x.closest('.fld'),bad=!x.value.trim()||(x.type==='tel'&&x.value.replace(/\D/g,'').length<9);w.classList.toggle('bad',bad);if(bad)ok=false});
  if(!ok){var first=$('.bad',f);if(first)first.scrollIntoView({behavior:'smooth',block:'center'});say('Please fill in the highlighted fields, then send again.');return}
  var data={},lines=['*New enquiry - RafGodwin Engineering*'];
  $$('input,select,textarea',f).forEach(function(x){
   if(!x.name)return;
   if(x.type==='checkbox'||x.type==='radio'){if(x.checked){data[x.name]=(data[x.name]?data[x.name]+', ':'')+x.value}return}
   if(x.value.trim())data[x.name]=x.value.trim()});
  Object.keys(data).forEach(function(k){lines.push(k+': '+data[k])});
  lines.push('Terms of Service: Accepted');
  var text=lines.join('\n');
  if(via==='wa'){
   var url='https://wa.me/'+WA+'?text='+encodeURIComponent(text);
   var a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
   say('Opening WhatsApp with your request ready to send. If nothing opened, <a href="'+url+'" target="_blank" rel="noopener">tap here to send it</a>, or use &ldquo;Email a copy instead&rdquo;.');
   return}
  var mailto='mailto:'+MAIL+'?subject='+encodeURIComponent('New enquiry - RafGodwin Engineering')+'&body='+encodeURIComponent(text.replace(/\*/g,''));
  var payload=Object.assign({_subject:'New enquiry - RafGodwin Engineering',_template:'table',_captcha:'false'},data);
  if(data.Email)payload._replyto=data.Email;
  say('Sending to '+MAIL+'...');
  fetch('https://formsubmit.co/ajax/'+MAIL,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(payload)})
   .then(function(r){if(!r.ok)throw 0;return r.json()})
   .then(function(){say('Thank you. Your request has been emailed to '+MAIL+'. We will reply within one working day.');f.reset();prog()})
   .catch(function(){say('We could not send it automatically. <a href="'+mailto+'">Tap here to email it from your mail app</a>, or use WhatsApp.')});
 })});

/* ---- hero: slow solar background (video if present, animated panels otherwise) ---- */
var bg=$('.hero-bg');
if(bg){
 var v=$('video',bg),cv=$('canvas',bg),reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(v&&!reduce){v.addEventListener('loadedmetadata',function(){v.playbackRate=.6});v.addEventListener('canplay',function(){bg.classList.add('has-video');v.play().catch(function(){})});v.load()}
 if(cv){
  var c=cv.getContext('2d'),W,H,t=0,dpr=Math.min(window.devicePixelRatio||1,2);
  function size(){W=cv.clientWidth;H=cv.clientHeight;cv.width=W*dpr;cv.height=H*dpr;c.setTransform(dpr,0,0,dpr,0,0)}
  size();window.addEventListener('resize',size);
  function draw(){
   c.fillStyle='#0b0e11';c.fillRect(0,0,W,H);
   var s=Math.max(54,W/20),ang=-.22,cols=Math.ceil(W/s)+8,rows=Math.ceil(H/s)+8,drift=(t*6)%s;
   c.save();c.translate(W*.55,H*.5);c.rotate(ang);c.translate(-W*.55-drift,-H*.5);
   for(var i=-4;i<cols;i++)for(var j=-4;j<rows;j++){
    var x=i*s,y=j*s*.62,sh=.5+.5*Math.sin(t*.5+i*.35+j*.5),a=.05+sh*.09;
    c.fillStyle='rgba(60,84,120,'+(.35+sh*.25)+')';c.fillRect(x+2,y+2,s-4,s*.62-4);
    c.fillStyle='rgba(217,164,65,'+a+')';c.fillRect(x+2,y+2,s-4,s*.62-4)}
   c.restore();
   var gx=W*(.2+.6*((Math.sin(t*.12)+1)/2)),g=c.createRadialGradient(gx,H*.25,10,gx,H*.25,W*.6);
   g.addColorStop(0,'rgba(255,214,140,.38)');g.addColorStop(1,'rgba(255,214,140,0)');c.fillStyle=g;c.fillRect(0,0,W,H);
   t+=.016;if(!reduce)requestAnimationFrame(draw)}
  draw()}
}
})();

/* ---- RAF: on-site assistant ----
   Behaves like a modern AI chat: thinking indicator, typed-out replies, follow-up chips, remembers the chat across pages.
   Answers come from this site's own content (no invented prices or promises).
   Optional: set window.RAF_ENDPOINT to an AI backend (POST {message, history} -> {reply}); RAF falls back to built-in answers if it fails. */
(function(){
'use strict';
var open=document.getElementById('raf-open');if(!open)return;
var WA=window.RG_WA||'233551120109',MAIL=window.RG_EMAIL||'info@rafgodwin.com',PH=window.RG_PHONE||'024 711 7982',TEL='tel:+233247117982',
MAPS='https://www.google.com/maps/search/?api=1&query=RafGodwin+Engineering+Kwashieman+Ofankor+Road+Sowutuom+Accra',SK='raf_chat_v1';
var wa=function(t){return 'https://wa.me/'+WA+'?text='+encodeURIComponent(t||'Hello RafGodwin Engineering, I have a question.')};
var hist=[],busy=false;

/* ---------- helpers ---------- */
function norm(s){return String(s||'').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim()}
function stem(w){return w.length>3?w.replace(/(es|s)$/,''):w}
function toks(s){return norm(s).split(' ').filter(Boolean).map(stem)}
function lev(a,b){if(Math.abs(a.length-b.length)>1)return 2;if(a==b)return 0;var i=0;while(i<a.length&&a[i]==b[i])i++;var x=a.slice(i),y=b.slice(i);if(x.slice(1)==y.slice(1)||x.slice(1)==y||x==y.slice(1))return 1;return 2}
var ALIAS={solor:'solar',sollar:'solar',cctvs:'cctv',camara:'camera',camaras:'camera',cameras:'camera',electrical:'electric',fense:'fence',fance:'fence',invertor:'inverter',inverta:'inverter',dumsor:'dumsor',whatsap:'whatsapp',whatsup:'whatsapp',watsapp:'whatsapp',qoute:'quote',quotation:'quote',quatation:'quote',color:'colour',energiser:'energizer',energisers:'energizer'};
function has(qt,w){w=stem(w);for(var i=0;i<qt.length;i++){var t=ALIAS[qt[i]]||qt[i];if(t==w||qt[i]==w||(w.length>=6&&t.length>=6&&lev(t,w)<2))return true}return false}
function esc(v){return String(v).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function pick(a){return a[Math.random()*a.length|0]}
/* tiny markdown: **bold**, [text](url), "- " bullets */
function md(t){var out=[],list=false;
 t.split('\n').forEach(function(l){var li=/^- /.test(l);
  if(li&&!list){out.push('<ul>');list=true}if(!li&&list){out.push('</ul>');list=false}
  var h=esc(li?l.slice(2):l).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,function(m,a,u){var ext=/^https?:/.test(u);return '<a href="'+u+'"'+(ext?' target="_blank" rel="noopener"':'')+'>'+a+'</a>'});
  out.push(li?'<li>'+h+'</li>':(h?'<p>'+h+'</p>':''))});
 if(list)out.push('</ul>');return out.join('')}
function R(text,chips,id){return{text:text,chips:chips||[],id:id||''}}

/* ---------- knowledge ---------- */
var ACT=[{t:'Call now',h:TEL},{t:'WhatsApp',h:wa()},{t:'Free quote',h:'quote.html'}];
var DEF=['Get a quote','Shop products','Delivery fees','Solar options','CCTV','Opening hours','Location','Talk to a person'];
var QUOTE_W=wa('Hello, I would like a free quote.');

/* ---------- live shop knowledge ----------
   RAF reads the same Supabase `products` table the shop uses, so new products, price changes, sales and stock levels
   show up in answers within ~30 seconds, with no edits to this file. Delivery fees mirror js/paystack.js (keep in sync). */
var SHOP={list:null,t:0,live:false,p:null};
var REGIONS={'Greater Accra':50,'Central':120,'Eastern':120,'Volta':150,'Ashanti':150,'Western':180,'Western North':200,'Oti':200,'Bono':200,'Bono East':220,'Ahafo':220,'Northern':280,'Savannah':300,'North East':300,'Upper East':300,'Upper West':300};
var PLACES={'accra':'Greater Accra','accra central':'Greater Accra','tema':'Greater Accra','madina':'Greater Accra','adenta':'Greater Accra','east legon':'Greater Accra','spintex':'Greater Accra','achimota':'Greater Accra','ofankor':'Greater Accra','sowutuom':'Greater Accra','sowutoum':'Greater Accra','kwashieman':'Greater Accra','dansoman':'Greater Accra','weija':'Greater Accra','osu':'Greater Accra','labone':'Greater Accra','teshie':'Greater Accra','nungua':'Greater Accra','ashaiman':'Greater Accra','kpone':'Greater Accra','dome':'Greater Accra','lapaz':'Greater Accra','kasoa':'Central','winneba':'Central','cape coast':'Central','mankessim':'Central','swedru':'Central','koforidua':'Eastern','nkawkaw':'Eastern','akosombo':'Eastern','suhum':'Eastern','ho':'Volta','hohoe':'Volta','keta':'Volta','aflao':'Volta','kumasi':'Ashanti','obuasi':'Ashanti','ejisu':'Ashanti','konongo':'Ashanti','takoradi':'Western','sekondi':'Western','tarkwa':'Western','axim':'Western','sefwi wiawso':'Western North','bibiani':'Western North','dambai':'Oti','sunyani':'Bono','berekum':'Bono','dormaa':'Bono','techiman':'Bono East','kintampo':'Bono East','atebubu':'Bono East','goaso':'Ahafo','tamale':'Northern','yendi':'Northern','damongo':'Savannah','bole':'Savannah','nalerigu':'North East','walewale':'North East','bolgatanga':'Upper East','bolga':'Upper East','navrongo':'Upper East','bawku':'Upper East','wa':'Upper West','lawra':'Upper West'};
var WEAK={solar:1,smart:1,home:1,security:1,kit:1,wifi:1,mono:1,with:1};
var STOP={};
('a an the is are was were do does did you your yours have has had any got sell sells selling buy buying price prices priced cost costs how much many what which whats of for in on at to me my i can could would will it its there and or this that stock available availability product item please want need looking look show tell about get some one s ghs gh cedi cedis online shop store raf cheap cheaper cheapest cheapes les expensive affordable lowest highest most best less more than under below over above within budget list all every see know give find recommend').split(' ').forEach(function(w){STOP[w]=1});

function money(x){return 'GHS '+Number(x||0).toLocaleString('en-GH',{minimumFractionDigits:0,maximumFractionDigits:2})}
function ptoks(s){s=String(s||'').toLowerCase().replace(/(\d)\s*(kva|kwh|kw|ah|mp|tb|km|w|v|a)\b/g,'$1$2').replace(/(\d)\.(\d)/g,'$1p$2').replace(/wi ?-?fi/g,'wifi').replace(/door ?-?bell/g,'doorbell');
 return norm(s).split(' ').filter(Boolean).map(function(w){w=ALIAS[w]||w;return stem(w.replace(/ies$/,'y'))})}
function creds(){
 if(typeof SUPABASE_URL!=='undefined'&&typeof SUPABASE_ANON_KEY!=='undefined')return Promise.resolve({u:SUPABASE_URL,k:SUPABASE_ANON_KEY});
 /* pages that don't load js/supabase.js: read the same two values from it, so there is one place to configure */
 return fetch('js/supabase.js').then(function(r){return r.ok?r.text():Promise.reject()}).then(function(t){
  var u=/SUPABASE_URL\s*=\s*'([^']+)'/.exec(t),k=/SUPABASE_ANON_KEY\s*=\s*'([^']+)'/.exec(t);return u&&k?{u:u[1],k:k[1]}:null}).catch(function(){return null})}
function useDemo(){if(!SHOP.list&&typeof DEMO_PRODUCTS!=='undefined'){SHOP.list=DEMO_PRODUCTS;SHOP.live=false;SHOP.t=Date.now()}}
function refresh(force){
 if(!force&&SHOP.list&&Date.now()-SHOP.t<30000)return Promise.resolve();
 if(SHOP.p)return SHOP.p;
 SHOP.p=creds().then(function(c){
  if(!c||/YOUR_/.test(c.u+c.k)){useDemo();return}
  var ctl=window.AbortController?new AbortController():null,tm=setTimeout(function(){if(ctl)ctl.abort()},5000);
  return fetch(c.u+'/rest/v1/products?select=id,name,category,price,old_price,stock,description,badge,featured&order=created_at.desc&limit=1000',{headers:{apikey:c.k,Authorization:'Bearer '+c.k},signal:ctl?ctl.signal:undefined})
   .then(function(r){clearTimeout(tm);return r.ok?r.json():Promise.reject()})
   .then(function(d){if(!Array.isArray(d))throw 0;SHOP.list=d;SHOP.live=true;SHOP.t=Date.now()})
 }).catch(function(){useDemo()}).then(function(){SHOP.p=null});
 return SHOP.p}

function sc(p,qs){var nt=ptoks(p.name),dt=ptoks(p.description),ct=ptoks(p.category),s=0,st=0,nm=0;
 qs.forEach(function(w){var h=0;
  if(nt.indexOf(w)>-1)h=2;
  else if(w.length>=6&&nt.some(function(x){return x.length>=6&&lev(x,w)<2}))h=2;
  else if(dt.indexOf(w)>-1)h=1;
  else if(ct.indexOf(w)>-1)h=.5;
  if(h){s+=h;if(!WEAK[w]&&h>=1)st++;if(h==2&&!WEAK[w])nm++}});
 return{p:p,s:s,st:st,nm:nm}}
function plink(p){return 'product.html?id='+encodeURIComponent(p.id)}
function inStock(p){return Number(p.stock)>0}
function saving(p){return p.old_price&&Number(p.old_price)>Number(p.price)?Number(p.old_price)-Number(p.price):0}
function line(p){
 var t='- **['+p.name+']('+plink(p)+')**: **'+money(p.price)+'**';
 if(saving(p))t+=' (was '+money(p.old_price)+')';
 if(!inStock(p))t+=', out of stock';else if(Number(p.stock)<=5)t+=', only '+p.stock+' left';
 return t}
function listText(a,max){max=max||8;var t=a.slice(0,max).map(line).join('\n');if(a.length>max)t+='\n- ...and '+(a.length-max)+' more in the [shop](shop.html)';return t}
function detail(p){
 var t='**'+p.name+'** is **'+money(p.price)+'**';
 if(saving(p))t+=' (was '+money(p.old_price)+', you save '+money(saving(p))+')';
 t+='.';
 if(!inStock(p))t+=' It’s currently **out of stock**. Message our team to ask about restocking.';
 else if(Number(p.stock)<=5)t+=' Only **'+p.stock+' left** in stock.';
 else t+=' In stock ('+p.stock+' available).';
 if(p.description){var d=String(p.description);t+='\n'+(d.length>170?d.slice(0,167)+'...':d)}
 t+='\n- Category: '+p.category+(p.badge?' ('+p.badge+')':'');
 t+='\n- [Open product page]('+plink(p)+') to add it to your cart or buy now';
 return t}
function findRegion(n){var best=null;
 Object.keys(PLACES).sort(function(a,b){return b.length-a.length}).some(function(p){if(new RegExp('\\b'+p+'\\b').test(n)){best=PLACES[p];return true}return false});
 if(best)return best;
 Object.keys(REGIONS).sort(function(a,b){return b.length-a.length}).some(function(r){if(new RegExp('\\b'+r.toLowerCase()+'\\b').test(n)){best=r;return true}return false});
 return best}
function feeTable(){var g={};Object.keys(REGIONS).forEach(function(r){(g[REGIONS[r]]=g[REGIONS[r]]||[]).push(r)});
 return Object.keys(g).map(Number).sort(function(a,b){return a-b}).map(function(f){return '- **'+money(f)+':** '+g[f].join(', ')}).join('\n')}
function pageProduct(){if(!/product\.html/.test(location.pathname))return null;var id=new URLSearchParams(location.search).get('id');
 return (SHOP.list||[]).filter(function(p){return String(p.id)===String(id)})[0]||null}
function shopContext(){var L=SHOP.list||[];
 return 'Online shop products (live): '+L.map(function(p){return p.name+' ['+p.category+'] '+money(p.price)+(saving(p)?' (was '+money(p.old_price)+')':'')+', '+(inStock(p)?p.stock+' in stock':'out of stock')}).join('; ')+'. Delivery fees by region: '+Object.keys(REGIONS).map(function(r){return r+' '+money(REGIONS[r])}).join(', ')+'. Pickup at Sowutoum office is free. Payment: Paystack (MoMo or card).'}

/* products matching a phrase (used when a question mixes buying and delivery) */
function quick(ql,L){var qs=ptoks(ql).filter(function(w){return w&&!STOP[w]}),
 sc2=L.map(function(p){return sc(p,qs)}).filter(function(x){return x.st>=1&&x.nm>=1}).sort(function(a,b){return b.s-a.s});
 var top=sc2.length?sc2[0].s:0;return sc2.filter(function(x){return x.s>=top-.5}).map(function(x){return x.p})}
function shopAnswer(q,n,P){
 var L=SHOP.list||[],ql=q.toLowerCase(),
 svc=P(/\b(install\w*|quotation|quote|survey|site visit|maintenance|repair\w*)\b/),
 hard=P(/\b(buy|purchase|order\w*|cart|basket|checkout|check out|paystack|stock|add to|online shop|online store|shop online|catalog\w*)\b/),
 dw=P(/\b(deliver\w*|shipping|ship|dispatch|courier|pick ?up|collect\w*)\b/),
 own=P(/\b(my|our) (own )?(shop|store)\b/);
 if(own&&!hard)return null;
 if(svc&&!hard)return null;
 if(!hard&&!dw&&P(/\b(open|opening|closing|hours?|sunday|saturday|monday|where|address|location|directions?|map|find you)\b/))return null;

 /* my cart */
 if(P(/\b(cart|basket)\b/)&&P(/\b(what|show|view|see|check|how many|total|contents?|in my|my cart|my basket|empty)\b/)&&!P(/\b(how (do|can|to)|add to|remove|clear)\b/)){
  var c=window.Cart?Cart.get():[];
  if(!c.length)return R('Your cart is empty right now. Browse the [shop](shop.html) and tap **Add to Cart** on anything you like.',[{t:'Open shop',h:'shop.html'},'Shop products'],'cart');
  var chg=[],t='In your cart:\n'+c.map(function(x){var lp=L.filter(function(p){return String(p.id)===String(x.id)})[0];
   if(lp&&Number(lp.price)!==Number(x.price))chg.push(x.name+' is now '+money(lp.price));
   return '- '+x.qty+' × **'+x.name+'**: '+money(x.price*x.qty)}).join('\n');
  t+='\n**Subtotal: '+money(Cart.subtotal())+'** (delivery is added at checkout, GHS 50 to 300 by region, or free pickup).';
  if(chg.length)t+='\nHeads up: the shop price has changed since you added some items ('+chg.join('; ')+'). Remove and re-add the item to get the current price.';
  return R(t,[{t:'View cart',h:'cart.html'},{t:'Checkout',h:'checkout.html'},'Delivery fees'],'cart')}

 /* delivery / pickup */
 if(dw){
  var reg=findRegion(n),pr=hard?quick(ql.replace(/\b(deliver\w*|ship\w*|pick ?up|dispatch|courier)\b.*$/,''),L):[],pre=pr.length===1?detail(pr[0])+'\n\n':'';
  if(P(/pick ?up|collect/)&&!P(/deliver|ship/))
   return R('You can **pick up your order free of charge** at our Sowutoum office (**JP9F+Q85, Kwashieman Ofankor Road, Sowutoum, Accra**). Choose **Pickup** at checkout. After you pay, our team calls you to arrange a time. [Open in Google Maps]('+MAPS+')',[{t:'Directions',h:MAPS},'Delivery fees','How to order'],'delivery');
  if(reg)return R(pre+'Delivery to **'+reg+'** costs **'+money(REGIONS[reg])+'**, added at checkout. Pickup at our Sowutoum office is free. After you pay, our team calls you to arrange delivery or pickup. I don’t have set delivery times on the site, so they’ll confirm timing when they call.',[{t:'Open shop',h:'shop.html'},'How to order','Payment options'],'delivery');
  return R(pre+'We deliver **across Ghana**. The fee depends on your region and is added at checkout:\n'+feeTable()+'\n**Pickup** at our Sowutoum office is free. Tell me your region or town and I’ll give you the exact fee. Our team calls you after payment to arrange delivery, and confirms timing then.',[{t:'Open shop',h:'shop.html'},'How to order','Payment options'],'delivery')}

 /* payments */
 if(P(/\b(pay|paid|paying|payments?|momo|mobile money|paystack|visa|mastercard|debit card|bank transfer|cash on delivery|cod)\b/)&&!P(/\b(financ\w*|instal+ment\w*|payment plan\w*|loan\w*|credit|deposit|part payment|payback)\b/))
  return R('Shop orders are paid at checkout through **Paystack**, by **mobile money (MoMo) or card**. It’s secure, and your order is confirmed as soon as the payment goes through. I don’t see cash on delivery or bank transfer as checkout options, so please ask our team if you need something else. Installation projects are different: their payment terms are in your signed quotation.',[{t:'Open shop',h:'shop.html'},'How to order',{t:'WhatsApp',h:wa('Hello, I have a question about paying for a shop order.')}],'payment');

 /* order help (tracking, cancel, refund, returns) */
 if(P(/\b(track\w*|where is my (order|item|package|parcel)|order status|cancel\w*|refund\w*|return\w*|exchang\w*|receipt|invoice|wrong (item|product)|damaged|faulty|defective|change (my )?(order|address))\b/)&&P(/\b(order|ordered|bought|purchas\w*|paid|payment|delivery|item|product|shop|online|refund|receipt)\b/))
  return R('After you pay, the confirmation page shows your **order number** (it starts with RFG-) and our team calls you to arrange delivery or pickup. I don’t have a published policy for tracking, changes, cancellations, returns or refunds, so I won’t guess. Please WhatsApp or call us with your order number and we’ll sort it out.',[{t:'WhatsApp',h:wa('Hello, I need help with my shop order. Order number: ')},{t:'Call now',h:TEL}],'order');

 /* bulk */
 if(P(/\b(bulk|wholesale|trade price\w*|reseller|distributor|dealer)\b/))
  return R('I don’t have bulk or trade pricing on the site. For larger orders, please talk to our team and they’ll quote you directly.',ACT,'bulk');

 /* how to order */
 if(P(/how (do|can|would|to) .*(buy|order|purchase|checkout|check out|shop)|\bordering\b|place an order|add to cart|buy online|order online|can i (buy|order|purchase)|how does (the )?(shop|ordering)/))
  return R('Ordering online takes a few minutes:\n- **Browse** the [shop](shop.html) by category or search, and sort by price\n- **Add to Cart** (or **Buy Now** to go straight to checkout)\n- **Checkout:** enter your name, phone, email and address, then choose delivery or free pickup\n- **Pay** securely with MoMo or card via Paystack\nYou’ll get an order number, and our team calls you to arrange delivery or pickup.',[{t:'Open shop',h:'shop.html'},'Delivery fees','Payment options'],'howorder');

 /* product knowledge */
 var bm=/(?:under|below|less than|within|up to|upto|max(?:imum)?|not more than|budget (?:of|is)?|around|about)\s*(?:ghs|gh₵|₵|ghc|cedis?)?\s*(\d[\d,]*(?:\.\d+)?)/.exec(ql),
 om=/(?:over|above|more than|at least|from|minimum)\s*(?:ghs|gh₵|₵|ghc|cedis?)?\s*(\d[\d,]*(?:\.\d+)?)/.exec(ql),
 maxp=bm?parseFloat(bm[1].replace(/,/g,'')):null,minp=om?parseFloat(om[1].replace(/,/g,'')):null;
 if(maxp!==null&&maxp<20)maxp=null;if(minp!==null&&minp<20)minp=null;
 var cue=hard||P(/\b(sell\w*|price\w*|cost\w*|how much|cheap\w*|expens\w*|have you got|do you have|got any|products?|items?|available|availability|left|remaining|how many|sale|deals?|discount\w*|promo\w*|budget|shop)\b/)||maxp!==null||minp!==null;
 var q2=ql.replace(bm?bm[0]:'\u0001',' ').replace(om?om[0]:'\u0001',' '),
 qs=ptoks(q2).filter(function(w){return w&&!STOP[w]}),
 scored=L.map(function(p){return sc(p,qs)}).filter(function(x){return x.st>=1}).sort(function(a,b){return b.s-a.s||b.nm-a.nm||(inStock(b.p)-inStock(a.p))}),
 top=scored.length?scored[0].s:0,
 picks=scored.filter(function(x){return x.s>=top-.5}).slice(0,12).map(function(x){return x.p}),
 strong=scored.length&&scored[0].nm>=1,
 cats=Object.keys(L.reduce(function(a,p){a[p.category]=1;return a},{})),
 CS={'smart home':/\b(smart ?home|automation)\b/,'security':/\b(security|cctv|cameras?|locks?|fenc\w*)\b/,'solar':/\b(solar|inverters?|batter\w*|panels?|renewable)\b/},
 cat=null;
 cats.forEach(function(c){var re=CS[String(c).toLowerCase()]||new RegExp('\\b'+String(c).toLowerCase()+'\\b');if(!cat&&re.test(n))cat=c});
 var inCat=cat?L.filter(function(p){return p.category===cat}):L,
 pool=(picks.length&&strong)?picks:inCat,
 scope=(picks.length&&strong)?'matching products':(cat?cat+' products':'products'),
 pp=pageProduct(),
 cover=qs.length>=2&&scored.length&&scored[0].nm>=1&&qs.every(function(w){return sc(scored[0].p,[w]).s>=1}),
 catw=ptoks(cats.join(' ')+' automation');
 if(!cue&&!cover)return null;

 if(!L.length&&SHOP.list&&P(/\b(shop|products?|sell\w*|buy|stock|price\w*|catalog\w*)\b/))
  return R('The shop doesn’t have any products listed at the moment. Please check back soon, or ask our team what we can supply.',ACT,'shop');
 if(!L.length)return null;

 var fmt=function(a){return a.slice().sort(function(x,y){return Number(x.price)-Number(y.price)})};
 var tail='\nWant installation too? Ask for a [free quote](quote.html).';

 /* budget */
 if((maxp!==null||minp!==null)&&(!P(/\bbudget\b/)||P(/\b(products?|items?|shop|buy|sell\w*|stock)\b/))){
  var ok=fmt(pool).filter(function(p){return (maxp===null||Number(p.price)<=maxp)&&(minp===null||Number(p.price)>=minp)}),
  rng=(minp!==null?'above '+money(minp):'')+(minp!==null&&maxp!==null?' and ':'')+(maxp!==null?'under '+money(maxp):'');
  if(!ok.length){var lo=fmt(pool)[0];return R('I don’t see any '+scope+' '+rng+' right now.'+(lo?' The lowest-priced one is '+money(lo.price)+':\n'+line(lo):''),[{t:'Open shop',h:'shop.html'},'Shop products'],'shop-budget')}
  return R('Here are '+scope+' '+rng+':\n'+listText(ok),[{t:'Open shop',h:'shop.html'},'Delivery fees','How to order'],'shop-budget')}

 /* sale */
 if(P(/\b(on sale|sale|sales|deals?|discount\w*|promo\w*|reduced|markdown|special offers?|price drop\w*|bargain\w*)\b/)){
  var sale=L.filter(function(p){return saving(p)>0||/sale/i.test(p.badge||'')}).sort(function(a,b){return saving(b)/Number(b.old_price||1)-saving(a)/Number(a.old_price||1)});
  if(!sale.length)return R('Nothing is marked down in the shop at the moment. Prices can change, so it’s worth checking back. For bulk or project pricing, our team can help.',[{t:'Open shop',h:'shop.html'},'Get a quote'],'sale');
  return R('These items are currently reduced:\n'+listText(sale)+'\nYou can’t stack extra discounts online, but our team can discuss larger orders.',[{t:'Open shop',h:'shop.html'},'How to order'],'sale')}

 /* cheapest / priciest / popular */
 if(P(/\b(cheap\w*|lowest|least expensive|affordable|most expensive|priciest|highest|best sell\w*|popular|top rated)\b/)){
  var arr=pool.slice();
  if(P(/best sell\w*|popular/)){var bs=arr.filter(function(p){return /best seller|popular/i.test(p.badge||'')});if(!bs.length)bs=arr.filter(function(p){return p.featured});
   if(bs.length)return R('Our best sellers'+(cat?' in '+cat:'')+':\n'+listText(bs),[{t:'Open shop',h:'shop.html'},'How to order'],'shop-top')}
  else if(P(/most expensive|priciest|highest/)){arr=fmt(arr).reverse();return R('The most expensive '+scope+':\n'+listText(arr.slice(0,3)),[{t:'Open shop',h:'shop.html'},'Delivery fees'],'shop-top')}
  else {arr=fmt(arr.filter(inStock).length?arr.filter(inStock):arr);return R('The lowest-priced '+scope+' in stock:\n'+listText(arr.slice(0,3)),[{t:'Open shop',h:'shop.html'},'Delivery fees'],'shop-top')}}

 /* "this product" on a product page */
 if(!picks.length&&pp&&P(/\b(this|it|that|this one)\b/)&&(hard||P(/\b(price|cost|how much|available|left)\b/)))
  return R(detail(pp),[{t:'Open product',h:plink(pp)},'Delivery fees','How to order'],'product');

 /* specific product(s) */
 if(picks.length&&(strong&&(hard||P(/\b(sell\w*|price\w*|cost\w*|how much|have you got|do you have|got any|available|availability|left|remaining|how many|products?|items?)\b/)||scored[0].nm>=2||cover))){
  if(picks.length===1||(scored.length>1&&scored[0].s-scored[1].s>=2))return R(detail(picks[0]),[{t:'Open product',h:plink(picks[0])},'Delivery fees','How to order'],'product');
  return R('I found **'+picks.length+'** matching products in the shop:\n'+listText(picks)+tail,[{t:'Open shop',h:'shop.html'},'Delivery fees','How to order'],'product')}

 /* category */
 if(cat&&P(/\b(sell\w*|products?|items?|do you have|have you got|got any|buy|shop|stock|available|catalog\w*|price\w*)\b/)){
  var ci=fmt(inCat);
  var miss=qs.some(function(w){return catw.indexOf(w)<0});
  return R((miss?'I couldn\u2019t find that exact item in the shop right now, but here is our **'+cat+'** range ('+ci.length+' product'+(ci.length===1?'':'s')+'):\n':'In our **'+cat+'** range we have '+ci.length+' product'+(ci.length===1?'':'s')+' in the shop:\n')+listText(ci)+'\n[See all '+cat+' products](shop.html?cat='+encodeURIComponent(cat)+')'+tail,[{t:'Open shop',h:'shop.html?cat='+encodeURIComponent(cat)},'Delivery fees','How to order'],'shop-cat')}

 /* overview */
 if(P(/\b(shop|products?|catalog\w*|sell\w*|buy|items?|equipment|what can i get)\b/)){
  var by={};L.forEach(function(p){(by[p.category]=by[p.category]||[]).push(Number(p.price))});
  var t='Our online **shop** sells genuine smart home, security and solar equipment, delivered across Ghana or ready for free pickup in Accra. Right now there are **'+L.length+' products**:\n'+
   Object.keys(by).map(function(c){var a=by[c];return '- **'+c+':** '+a.length+' item'+(a.length===1?'':'s')+', from '+money(Math.min.apply(null,a))+' to '+money(Math.max.apply(null,a))}).join('\n')+
   '\nYou pay securely by MoMo or card. Ask me about any product, price, stock or delivery. We also do full installation if you need it.';
  return R(t,[{t:'Open shop',h:'shop.html'}].concat(Object.keys(by).slice(0,3).map(function(c){return c+' products'})),'shop')}
 return null}


function answer(q){
 var n=norm(q),qt=toks(q),
 A=function(){for(var i=0;i<arguments.length;i++)if(has(qt,arguments[i]))return true;return false},
 P=function(re){return re.test(n)};

 /* small talk */
 if(/^(hi|hello|hey|hiya|good (morning|afternoon|evening)|howdy|yo)\b/.test(n)&&n.split(' ').length<5)
  return R('Hello! I\u2019m **RAF**, RafGodwin Engineering\u2019s assistant. Ask me about our services, the online shop, quotes, location or opening hours.',['Get a quote','Shop products','Opening hours'],'hi');
 if(P(/\b(thank|thanks|thx|cheers|appreciate)\b/))return R(pick(['You\u2019re welcome! Anything else I can help with?','Happy to help! Ask me anything else about RafGodwin Engineering.']),['Get a quote','Opening hours'],'ty');
 if(P(/\b(bye|goodbye|see you|cya)\b/))return R('Thanks for stopping by. We\u2019re here whenever you need us.',[],'bye');
 if(P(/\b(who|what) are you\b|your name|who is raf|what is raf|are you (a )?(bot|ai|human|real)|talking to/))
  return R('I\u2019m **RAF**, the virtual assistant for RafGodwin Engineering. I\u2019m automated, and I answer from this website\u2019s information: our services, our online shop (live products, prices and stock), delivery, quotes, location and hours. For anything I can\u2019t answer, our team is a call or WhatsApp away.',ACT,'about-raf');
 if(P(/\bhow are you\b/))return R('Doing great, thanks for asking! What would you like to know about our smart home, security or solar services?',DEF.slice(0,3),'hru');

 /* online shop: live products, prices, stock, delivery, payment, orders */
 var sr=shopAnswer(q,n,P);if(sr)return sr;

 /* contact / talk to a person */
 if((A('phone','call','number','contact','reach','whatsapp','telephone','email','mail','person','human','agent','speak','talk','engineer')||P(/get in touch|customer care/))&&!A('quote','price','cost')&&!P(/\bhow long\b|(control|view|monitor|watch|check|manage).*(phone|app|remote|mobile)|from my phone|mobile app/)){
  if(P(/e ?mail|mail us/)&&!A('phone','call','whatsapp'))return R('You can email us at [info@rafgodwin.com](mailto:'+MAIL+'). Every form on this site also has an \u201cEmail a copy instead\u201d button. For a faster reply, WhatsApp is usually quickest.',ACT,'contact');
  return R('You can reach our team here:\n- **Call:** [024 711 7982]('+TEL+')\n- **WhatsApp:** [+233 55 112 0109]('+wa()+')\n- **Email:** [info@rafgodwin.com](mailto:'+MAIL+')\nWe reply within one working day, and usually much faster on WhatsApp.',ACT,'contact')}

 /* coverage areas */
 if(P(/(do|can|will) you (travel|come|operate|work|install|serve) (to|in|outside|across|around|at)\b|which (areas|regions|towns|cities)|coverage|nationwide|outside accra|all over ghana|across ghana|other regions?|\b(kumasi|tema|kasoa|takoradi|tamale|cape coast|koforidua|weija|madina|adenta|spintex|east legon|achimota|sunyani)\b/))
  return R('We install **across Ghana**. Our quote form lists Sowutuom/Kwashieman, Ofankor/Achimota, Accra Central, East Legon/Airport, Tema/Spintex, Madina/Adenta, Kasoa/Weija and Kumasi, plus \u201cOther region in Ghana\u201d. Tell us your location in the [quote form](quote.html) and we\u2019ll confirm a survey date.',[{t:'Free quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'Location'],'areas');

 /* location */
 if(A('where','location','address','direction','map','visit','located','sowutuom','kwashieman','ofankor')||P(/find (you|us)|how (do|can) i get (to|there|here)|way to you|(your|the|come to) (office|shop|showroom)/))
  return R('Our office is at **JP9F+Q85, Kwashieman Ofankor Road, Sowutuom, Accra**.\n- [Open in Google Maps]('+MAPS+')\nBest to call or WhatsApp before you visit so we can have an engineer ready.',[{t:'Directions',h:MAPS},{t:'Call now',h:TEL},'Opening hours'],'loc');

 /* hours */
 if(A('hour','open','close','closing','sunday','saturday','monday','tuesday','wednesday','thursday','friday','weekend','opening')||P(/what time|until when|till when|working days/))
  return R('Our hours:\n- **Monday to Friday:** 8:00 am to 6:00 pm\n- **Saturday:** 9:00 am to 4:00 pm\n- **Sunday:** closed\nOutside these hours you can still [WhatsApp us]('+wa()+') or send a [quote request](quote.html) and we\u2019ll reply within one working day.',[{t:'Call now',h:TEL},{t:'WhatsApp',h:wa()},'Location'],'hours');

 /* things the site does not say: never invent them */
 if(P(/\b(warrant\w*|guarantee\w*|financ\w*|instal+ment\w*|payment plan\w*|pay (in|by|with)|momo|mobile money|credit|loan|discount\w*|brands?|certificat\w*|licen[sc]\w*|insur\w*|job|jobs|career\w*|hiring|vacanc\w*|24 ?7|emergency|after hours|same day|turnaround|lead time|spare parts?|second ?hand|refurbish\w*)\b/)||P(/how long (does|will|do|would) .*(take|install|complete|finish)|how soon|how fast/))
  return R('I don\u2019t have that detail on the website, and I don\u2019t want to guess. Our team can tell you quickly:',ACT,'unknown');

 /* pricing / quotes */
 if(A('price','pricing','cost','quote','estimate','budget','cheap','expensive','afford','charge','fee','rate')||P(/how much|free survey|site visit|consultation/))
  return R('We don\u2019t publish fixed prices because every property is different. Instead we do a **free site survey**, then send an **itemised quotation**, so you only pay for what your property needs. It\u2019s no obligation, with clear pricing and no hidden costs.\nQuotes are non-binding until confirmed in writing after the survey. Our [quote form](quote.html) lets you pick a budget range (from under GH\u20b55,000 to above GH\u20b5150,000) so we can match you with the right engineer.',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'How it works'],'pricing');

 /* phone control / internet / maintenance / lifespan */
 if(P(/(control|view|monitor|watch|check|manage).*(phone|app|remote|remotely|anywhere|mobile)|from my phone|mobile app|\bapp\b/))
  return R('Yes. Lighting, locks, gates, cameras and solar monitoring can all be viewed and controlled **from your phone**, and many by voice. Remote viewing works on iOS and Android.',['Internet needs','Smart home','CCTV'],'app');
 if(A('internet','wifi','bandwidth','mbps','connection','broadband','router')||P(/wi ?fi|data connection/))
  return R('Remote viewing needs a stable connection. A typical home needs roughly **5 to 10 Mbps upload** for a few cameras. **Local control and recording keep working** even when the internet is down.',['CCTV','Blackout backup'],'internet');
 if(P(/how long (will|do|does|would).*(last|solar|batter|panel|inverter)|lifespan|life span|last for|durab|replace(ment)? (my )?batter/))
  return R('As a guide: quality **solar panels last 20+ years**, **lithium batteries typically 8 to 12 years** depending on use, and **inverters 8 to 10 years**. Proper sizing and care extend life.',['Maintenance','Solar options'],'lifespan');
 if(P(/maintenance|maintain|servicing|repair|clean(ing)?|care plan|aftercare|after ?install|inspect|support|service plan/))
  return R('We recommend:\n- **Cameras, locks and fences:** inspection about every 6 months\n- **Solar panels:** cleaning every 3 to 6 months (more often in harmattan dust)\n- **Batteries:** a check once a year\nWe offer **care plans** and we support you after installation. More in the [FAQs](faq.html).',[{t:'Ask about a care plan',h:wa('Hello, I would like to ask about a care plan.')},'Get a quote'],'maintenance');

 if(P(/blackout|dumsor|power (cut|outage|failure)|outage|load shedding|\bups\b|backup|back up|lights? off|grid fail/))
  return R('Yes, we design systems to **keep working during blackouts**. We add UPS or solar-battery backup so cameras, routers, locks, gate motors and electric-fence energisers stay on, and our solar packages keep essentials like lights, TV, fans and Wi-Fi running (fridge and pump from the Comfort package up). Local control and recording also continue when the internet is down. See [Solar](solar.html).',[{t:'Request a quote',h:'quote.html'},'Solar options'],'backup');
 /* process */
 if(A('survey','process','steps','started','begin')||P(/how (does|do) (it|this|the process|ordering)|how it works|what happens (after|next|when i)|next step|get started|where do i start|how do i (start|order|book|apply)/))
  return R('It\u2019s four simple steps:\n- **Submit:** complete the short [quote form](quote.html)\n- **Survey:** we visit and measure, free\n- **Quote:** you receive an itemised proposal\n- **Install:** our engineers deliver the system and train you\nWe reply within one working day.',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W}],'process');

 /* services: specific topics */
 var solar=A('solar','panel','inverter','battery','renewable','hybrid','offgrid','lithium','grid','energy','electricity')||P(/off grid/);
 if(P(/\b(commercial|business|businesses|company|factory|school|church|warehouse|shop|office|energy audit|audit|payback|tariff)\b/)&&solar&&!P(/our office|your office/))
  return R('For businesses we offer:\n- **Energy audit and load profiling**\n- **Large rooftop and ground-mount solar**\n- **Hybrid systems with generator integration**\n- **Monitoring dashboards and maintenance contracts**\nWe analyse your consumption, design the right solar and storage system, and show the payback before you invest. See [Commercial Energy](commercial-energy.html).',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'Solar options'],'commercial');
 if(solar&&P(/residential|home solar|house|household|package|essentials|comfort|whole home|my home|apartment|flat/))
  return R('Our residential solar packages:\n- **Essentials:** lights, TV, fans, Wi-Fi\n- **Comfort:** adds fridge, water pump and selected AC\n- **Whole-home hybrid** with battery storage\n- **Off-grid systems** for remote properties\nWe survey your appliances and roof, recommend a package, and show the expected backup time before you commit. See [Residential Solar Packages](residential-solar.html).',[{t:'Request a quote',h:'quote.html'},'Blackout backup','Commercial solar'],'residential');
 if(solar)
  return R('We design **hybrid, off-grid and grid-tied** solar around your actual load, so essentials stay on and bills come down:\n- Honest load analysis and system sizing\n- Quality panels, inverters and batteries\n- Neat roof mounting and safe cabling\nSee [Solar](solar.html), [Residential Packages](residential-solar.html) and [Commercial Energy](commercial-energy.html).',[{t:'Request a quote',h:'quote.html'},'Home packages','Commercial solar','Blackout backup'],'solar');
 if(A('cctv','camera','surveillance','footage','dvr','nvr','recording','playback')||P(/night vision|security camera/))
  return R('Our CCTV systems include:\n- **HD and night-vision cameras**\n- **Live view and playback** on iOS and Android\n- **Cloud and local recorder** storage\n- **Motion alerts** and smart detection\n- **UPS or solar backup** so cameras stay on\nWe plan camera positions for real coverage, cable cleanly and set up secure remote viewing. See [CCTV & Surveillance](cctv.html).',[{t:'Request a quote',h:'quote.html'},'Internet needs','Blackout backup'],'cctv');
 if(A('fence','fencing','perimeter','energiser','energizer','electric')||P(/electric fence/)){
  if(P(/safe|danger|shock|harm|kill|hurt/))return R('Yes, electric fencing is safe **when installed to standard**. Energisers deliver short, high-voltage, low-current pulses, with correct earthing, warning signs and clearances, which is how we install every fence. See [Electric Fencing](electric-fencing.html).',[{t:'Request a quote',h:'quote.html'},'CCTV'],'fence-safe');
  return R('Our electric fences are installed to safety standards:\n- **Wall-top and freestanding** systems\n- **Alarm-linked energisers** with alerts\n- **Safe earthing** and warning signage\n- **Solar or battery backup** for continuous protection\nThey can also be paired with cameras to verify intrusions. See [Electric Fencing](electric-fencing.html).',[{t:'Request a quote',h:'quote.html'},'Is fencing safe?','CCTV'],'fence')}
 if(A('lock','fingerprint','biometric','keyless','gate','intercom','access','keypad','pin')||P(/smart lock|access control/))
  return R('We fit smart entry systems:\n- **Fingerprint, PIN, card and app** unlock\n- **Remote lock status** and access history\n- **Temporary codes** for guests and staff\n- **Sliding and swing gate motors** with remote and app control\n- **Multi-user access control** for estates and offices\nSee [Smart Locks & Gates](smart-locks.html).',[{t:'Request a quote',h:'quote.html'},'CCTV','Electric fence'],'locks');
 if(P(/smart home|home automation|automation|automate|automated|lighting|\blights?\b|appliances?|voice|alexa|google home|curtains?|climate|aircon|air condition|\bac\b|geyser|sockets?|\bpump\b|scenes?/))
  return R('We connect lighting, appliances, air-conditioning, gates and security into **one app or voice-controlled system**:\n- Scene-based lighting and dimming\n- Smart appliance and socket control (geysers, pumps)\n- Climate and AC scheduling to cut power bills\n- Voice and app control, with local backup when the internet drops\nSee [Smart Home & Automation](smart-home.html).',[{t:'Request a quote',h:'quote.html'},'Internet needs','Smart locks'],'smarthome');
 if(A('security','secure','protect','safety','burglar','theft','thief','intruder','alarm','break'))
  return R('We build security **in layers**: deter at the perimeter, detect on approach, verify with cameras and control every entry. That means electric fencing, HD CCTV, biometric locks and automated gates all working together. See [Security & Access Control](security.html).',[{t:'Request a quote',h:'quote.html'},'CCTV','Electric fence','Smart locks'],'security');

 /* overview */
 if(A('service','offer','provide','sell','products')||P(/what do you do|what can you do/))
  return R('We\u2019re an Accra-based team with **three core service lines**:\n- **Smart Home & Automation:** [see more](smart-home.html)\n- **Security & Access Control:** CCTV, electric fencing, smart locks and gates ([overview](security.html))\n- **Solar & Renewable Energy:** residential and commercial ([overview](solar.html))\nWe also run an **online shop** for smart home, security and solar equipment ([open the shop](shop.html)). Which one would you like to hear about?',['Shop products','Solar options','CCTV','Electric fence'],'services');

 /* company / social / reviews / portfolio / policies */
 if(P(/who (made|built|designed|created|developed) (this|the|your)? ?(website|site)|web ?developer|website by/))
  return R('This website was designed and developed by Clemence, [+233 55 867 7511](tel:+233558677511).',[],'dev');
 if(A('about','company','clients','experience','mission','values','founded','history','established','trust','legit')||P(/who (are|is) (rafgodwin|raf godwin)/))
  return R('RafGodwin Engineering is an **Accra-based engineering firm** delivering smart home automation, security and solar systems, with **900+ clients served**. Our mission is to modernise and protect Ghanaian homes and businesses by making intelligent, secure and energy-independent living accessible. We stand for integrity, craftsmanship, reliability and service. More on the [About page](about.html).',['Get a quote','Our services'],'about');
 if(A('review','rating','testimonial','feedback','google','reputation','stars'))
  return R('We don\u2019t publish ratings on this site, but you can read what clients say on Google. If you\u2019ve worked with us, please [leave a Google review](testimonials.html) in under a minute.',[{t:'Reviews page',h:'testimonials.html'}],'reviews');
 if(A('instagram','tiktok','social','insta','follow'))
  return R('You\u2019ll find our Instagram and TikTok links in the footer and on the [Contact page](contact.html).',['Talk to a person'],'social');
 if(A('portfolio','projects','examples','gallery','photos','pictures','completed')||P(/past work|your work/))
  return R('See some of our completed installations, like a rooftop solar array and a smart lock installation in Accra, on the [Portfolio page](portfolio.html).',[{t:'Portfolio',h:'portfolio.html'},'Get a quote'],'portfolio');
 if(A('terms','privacy','policy','data','personal','legal','consent','cookie'))
  return R('In short: the site\u2019s content is general information; quotes are non-binding until confirmed in writing after a site survey; we use your details only to respond to you by WhatsApp, phone or email, and we do **not sell your data**. Final specifications, prices and timelines are agreed in your signed quotation. You can reopen the full terms from the footer link \u201cTerms of Service\u201d.',[],'legal');
 if(A('faq','question','faqs'))
  return R('The [FAQs](faq.html) cover maintenance, internet needs, blackouts, battery life, electric fence safety and phone control. You can also just ask me.',DEF.slice(0,3),'faq');

 /* site map */
 if(P(/site ?map|what pages|which pages|pages (do|are)|where (can|do) i find|navigate|menu|sections/))
  return R('Here\u2019s what is on the site:\n- [Home](index.html), [About](about.html), [Portfolio](portfolio.html), [Reviews](testimonials.html), [FAQs](faq.html), [Contact](contact.html)\n- Services: [Smart Home](smart-home.html), [Security](security.html), [CCTV](cctv.html), [Electric Fencing](electric-fencing.html), [Smart Locks & Gates](smart-locks.html), [Solar](solar.html), [Residential Solar](residential-solar.html), [Commercial Energy](commercial-energy.html)\n- [Online Shop](shop.html), [Cart](cart.html) and [Checkout](checkout.html)\n- [Request a Quote](quote.html)',['Shop products','Get a quote'],'sitemap');

 /* fallback */
 if(qt.length<=3)return R('I couldn\u2019t find that on our website. Our team will be glad to help, so please ask them directly.',ACT,'nomatch');
 return R('I\u2019m not sure I have that one. I can help with **services** (smart home, CCTV, fencing, locks, solar), the **online shop** (products, prices, stock, delivery), **quotes**, **location** and **opening hours**. For anything else, our team is happy to help.',DEF.slice(0,3).concat(ACT.slice(0,2)),'fallback');
}

/* compound questions: "do you do CCTV and what time do you open?" -> answer each part */
function respond(t){
 var parts=t.split(/\?+\s*|\s+(?:and|also|plus)\s+(?=(?:what|how|do|does|can|where|when|is|are|which|who|will)\b)/i).map(function(x){return x.trim()}).filter(function(x){return x.split(/\s+/).length>=2});
 if(parts.length<2||parts.length>3)return answer(t);
 var seen={},rs=parts.map(answer).filter(function(r){if(/^(fallback|nomatch)$/.test(r.id)||seen[r.id])return false;seen[r.id]=1;return true});
 if(rs.length<2)return rs.length?rs[0]:answer(t);
 return R(rs.map(function(r){return r.text}).join('\n\n'),rs[rs.length-1].chips,rs.map(function(r){return r.id}).join('+'))
}

/* ---------- UI ---------- */
var wrap=document.createElement('div');wrap.className='raf';wrap.setAttribute('role','dialog');wrap.setAttribute('aria-label','Chat with RAF');
wrap.innerHTML='<div class="raf-h"><img src="assets/img/logo-mark.png" alt=""><div><b>RAF <span>Assistant</span></b><small>Smart home experts</small></div><button type="button" aria-label="Close chat">&times;</button></div><div class="raf-log" role="log" aria-live="polite"></div><div class="raf-chips"></div><form class="raf-f"><input type="text" enterkeyhint="send" placeholder="Ask about services, shop, prices, hours" aria-label="Your question" autocomplete="off" maxlength="300"><button type="submit">Send</button></form>';
document.body.appendChild(wrap);
var log=wrap.querySelector('.raf-log'),chips=wrap.querySelector('.raf-chips'),inp=wrap.querySelector('input'),sendBtn=wrap.querySelector('.raf-f button');
function scroll(){log.scrollTop=log.scrollHeight}
function save(){try{sessionStorage.setItem(SK,JSON.stringify({h:hist.slice(-40),o:wrap.classList.contains('open')}))}catch(e){}}
function add(html,user){var d=document.createElement('div');d.className='raf-m'+(user?' u':'');if(user)d.textContent=html;else d.innerHTML=html;log.appendChild(d);scroll();return d}
function setChips(list){
 chips.innerHTML='';
 (list&&list.length?list:DEF).forEach(function(c){
  if(typeof c==='object'){var a=document.createElement('a');a.href=c.h;a.textContent=c.t;if(/^https?:/.test(c.h)){a.target='_blank';a.rel='noopener'}chips.appendChild(a)}
  else{var b=document.createElement('button');b.type='button';b.textContent=c;b.onclick=function(){ask(c)};chips.appendChild(b)}});
 chips.scrollLeft=0}
var STATUS={pricing:'Checking how quotes work\u2026',loc:'Finding our location\u2026',hours:'Checking our hours\u2026',solar:'Looking up solar options\u2026',residential:'Looking up solar packages\u2026',commercial:'Looking up business energy\u2026',cctv:'Checking camera options\u2026',fence:'Checking fence details\u2026',locks:'Checking entry systems\u2026',smarthome:'Checking smart home options\u2026',security:'Checking security options\u2026',backup:'Checking backup power\u2026',process:'Checking the steps\u2026',areas:'Checking coverage\u2026',shop:'Checking the shop\u2026','shop-cat':'Checking the shop\u2026','shop-budget':'Checking prices\u2026','shop-top':'Checking prices\u2026',sale:'Checking current prices\u2026',product:'Checking price and stock\u2026',delivery:'Checking delivery rates\u2026',payment:'Checking payment options\u2026',order:'Checking order help\u2026',howorder:'Checking the steps\u2026',cart:'Looking at your cart\u2026',sitemap:'Looking at the site\u2026'};
function think(id){
 var d=document.createElement('div');d.className='raf-m think';
 d.innerHTML='<span class="raf-dots" aria-hidden="true"><i></i><i></i><i></i></span><span class="raf-st">Thinking\u2026</span>';
 log.appendChild(d);scroll();
 var st=d.querySelector('.raf-st'),steps=['Thinking\u2026',STATUS[id]||'Reading the site\u2026','Putting my answer together\u2026'],i=0;
 var t=setInterval(function(){i=Math.min(i+1,steps.length-1);st.textContent=steps[i]},650);
 d.stop=function(){clearInterval(t);d.remove()};return d}
function stream(el,html,done){
 var parts=html.split(/(<[^>]+>)/).filter(Boolean),ch=[];
 parts.forEach(function(p){if(p[0]==='<')ch.push(p);else p.split(/(\s+)/).forEach(function(w){if(w)ch.push(w)})});
 var i=0,out='',reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(reduce){el.innerHTML=html;done();return}
 el.classList.add('typing');
 (function step(){var n=0;while(i<ch.length&&n<3){out+=ch[i];if(ch[i][0]!=='<'&&!/^\s+$/.test(ch[i]))n++;i++}
  el.innerHTML=out;scroll();
  if(i<ch.length)setTimeout(step,22+Math.random()*28);else{el.classList.remove('typing');done()}})()}
function reply(r){
 var html=md(r.text),th=think(r.id),wait=Math.min(2200,Math.max(1100,700+r.text.length*3));
 return new Promise(function(res){setTimeout(function(){th.stop();var m=add('');
  stream(m,html,function(){hist.push({r:'bot',t:html,c:r.chips});save();setChips(r.chips);res()})},wait)})}
function setBusy(v){busy=v;sendBtn.disabled=v;wrap.classList.toggle('busy',v);chips.classList.toggle('dis',v)}
function ask(q){
 q=String(q||'').trim();if(!q||busy)return;
 add(q,true);hist.push({r:'user',t:q,u:1});save();inp.value='';setBusy(true);
 var fin=function(){setBusy(false)};
 /* pull the latest products/prices/stock first (cached 30s; never waits more than 3.5s) */
 Promise.race([refresh(),new Promise(function(r){setTimeout(r,3500)})]).then(function(){
  if(window.RAF_ENDPOINT){
   var th=think('');
   fetch(window.RAF_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q,shop:shopContext(),history:hist.slice(-10).map(function(h){return{role:h.r==='bot'?'assistant':'user',text:h.r==='bot'?h.t.replace(/<[^>]+>/g,''):h.t}})})})
    .then(function(r){return r.ok?r.json():Promise.reject()}).then(function(j){if(!j.reply)throw 0;th.stop();var m=add(''),h=md(j.reply);stream(m,h,function(){hist.push({r:'bot',t:h});save();fin()})})
    .catch(function(){th.stop();reply(respond(q)).then(fin)});
   return}
  var r;try{r=respond(q)}catch(e){r=R('Sorry, something went wrong on my side. Please try again, or reach our team directly.',ACT,'err')}
  reply(r).then(fin)})}
wrap.querySelector('form').onsubmit=function(e){e.preventDefault();ask(inp.value)};

var mobile=function(){return window.matchMedia('(max-width:600px)').matches};
function fit(){var vv=window.visualViewport;if(mobile()&&vv){wrap.style.setProperty('--rafh',vv.height+'px');wrap.style.transform='translateY('+vv.offsetTop+'px)';scroll()}else{wrap.style.removeProperty('--rafh');wrap.style.transform=''}}
if(window.visualViewport){visualViewport.addEventListener('resize',fit);visualViewport.addEventListener('scroll',fit)}
function welcome(){var html=md('Hi, I\u2019m **RAF**. Ask me anything about RafGodwin Engineering: services, our online shop (products, prices, delivery), quotes, location or opening hours.');add(html);hist.push({r:'bot',t:html,c:DEF});setChips(DEF)}
function toggle(f){
 var o=f===undefined?!wrap.classList.contains('open'):f;
 wrap.classList.toggle('open',o);document.body.classList.toggle('raf-lock',o&&mobile());open.classList.toggle('hide',o&&mobile());fit();
 if(o){refresh();if(!log.children.length)welcome();if(!mobile())setTimeout(function(){inp.focus()},50);scroll()}
 save()}
open.onclick=function(){toggle()};open.addEventListener('mouseenter',function(){refresh()},{once:true});open.addEventListener('touchstart',function(){refresh()},{once:true,passive:true});wrap.querySelector('.raf-h button').onclick=function(){toggle(false);open.focus()};
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&wrap.classList.contains('open'))toggle(false)});

/* restore chat when moving between pages */
(function(){var s=null;try{s=JSON.parse(sessionStorage.getItem(SK)||'null')}catch(e){}
 if(s&&s.h&&s.h.length){hist=s.h;hist.forEach(function(m){add(m.t,m.r==='user')});var last=hist[hist.length-1];if(last.r==='bot')setChips(last.c);else setChips(DEF)}
 else setChips(DEF);
 if(s&&s.o)toggle(true)})();
})();
