/* Admin panel: real Supabase writes (auth, products, storage, orders) */
(function(){
const $=id=>document.getElementById(id),toast=m=>{const t=$('toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',2400)};
if(!window.sb){document.body.innerHTML='<div class="login"><h1>Supabase not configured</h1><p>Paste your URL and anon key in <code>js/supabase.js</code> (see SUPABASE_SETUP.md).</p></div>';return}
/* ---- login page ---- */
if($('loginForm')){
  sb.auth.getSession().then(({data})=>{if(data.session)location.href='admin.html'});
  $('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('err').textContent='';
    const {error}=await sb.auth.signInWithPassword({email:$('em').value.trim(),password:$('pw').value});
    if(error)$('err').textContent=error.message;else location.href='admin.html'});
  return}
/* ---- admin page ---- */
let products=[],orders=[],editId=null;
const M=RG.money,E=RG.esc;
async function guard(){const {data}=await sb.auth.getSession();if(!data.session){location.href='admin-login.html';return false}$('who').textContent=data.session.user.email;return true}
function tab(n){['dash','products','orders'].forEach(t=>{$('t-'+t).hidden=t!==n;document.querySelector(`[data-tab=${t}]`).classList.toggle('on',t===n)})}
async function load(){
  const [p,o]=await Promise.all([sb.from('products').select('*').order('created_at',{ascending:false}),sb.from('orders').select('*').order('created_at',{ascending:false})]);
  products=p.data||[];orders=o.data||[];if(p.error||o.error)toast((p.error||o.error).message);
  $('sP').textContent=products.length;$('sO').textContent=orders.length;$('sR').textContent=M(orders.filter(x=>x.payment_status==='paid').reduce((a,x)=>a+ +x.total,0));
  $('pBody').innerHTML=products.map(p=>`<tr><td><img src="${E(p.image_url)}" alt=""></td><td>${E(p.name)}</td><td>${E(p.category)}</td><td>${M(p.price)}</td><td>${p.stock}</td><td>${p.featured?'★':''}</td>
   <td><button class="ab" data-edit="${p.id}">Edit</button><button class="ab r" data-del="${p.id}">Delete</button></td></tr>`).join('')||'<tr><td colspan="7">No products yet.</td></tr>';
  $('oBody').innerHTML=orders.map(o=>`<tr><td>${E(o.order_number)}</td><td>${new Date(o.created_at).toLocaleDateString('en-GB')}</td><td>${E(o.customer_name)}</td><td>${E(o.customer_phone)}</td><td>${M(o.total)}</td>
   <td><span class="pill ${o.payment_status==='paid'?'ok':'warn'}">${E(o.payment_status)}</span></td><td><span class="pill ${o.order_status==='completed'?'ok':'warn'}">${E(o.order_status)}</span></td>
   <td><button class="ab" data-view="${o.id}">View</button><button class="ab r" data-odel="${o.id}">Delete</button></td></tr>`).join('')||'<tr><td colspan="8">No orders yet.</td></tr>'}
function openProd(p){editId=p?p.id:null;$('pTitle').textContent=p?'Edit Product':'Add Product';
  ['name','category','price','old_price','stock','description','badge'].forEach(k=>$('f_'+k).value=p?(p[k]??''):(k==='category'?'Smart Home':''));
  $('f_featured').checked=!!p?.featured;$('f_image').value='';$('pm').classList.add('open')}
async function saveProd(e){e.preventDefault();const btn=$('saveBtn');btn.disabled=true;btn.textContent='Saving…';
  try{let url=editId?products.find(x=>x.id===editId).image_url:'';const file=$('f_image').files[0];
    if(file){const path=Date.now()+'-'+file.name.replace(/[^a-z0-9.]+/gi,'-');const up=await sb.storage.from('products-images').upload(path,file,{upsert:false});if(up.error)throw up.error;
      url=sb.storage.from('products-images').getPublicUrl(path).data.publicUrl}
    if(!url)throw new Error('Please choose a product image.');
    const name=$('f_name').value.trim();
    const row={name,category:$('f_category').value,price:+$('f_price').value,old_price:$('f_old_price').value?+$('f_old_price').value:null,stock:parseInt($('f_stock').value||0),description:$('f_description').value,badge:$('f_badge').value||null,featured:$('f_featured').checked,image_url:url};
    if(editId){const r=await sb.from('products').update(row).eq('id',editId);if(r.error)throw r.error}
    else{row.slug=name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')+'-'+Math.random().toString(36).slice(2,6);const r=await sb.from('products').insert(row);if(r.error)throw r.error}
    $('pm').classList.remove('open');toast('Saved');await load()}
  catch(err){alert(err.message)}finally{btn.disabled=false;btn.textContent='Save'}}
function csv(){const rows=[['Order','Date','Name','Phone','Email','Region','City','Address','Items','Subtotal','Delivery','Total','Payment','Status','Reference']];
  orders.forEach(o=>rows.push([o.order_number,o.created_at,o.customer_name,o.customer_phone,o.customer_email,o.region,o.city,o.address,(o.items||[]).map(i=>i.name+' x'+i.qty).join('; '),o.subtotal,o.delivery_fee,o.total,o.payment_status,o.order_status,o.paystack_reference]));
  const b=new Blob([rows.map(r=>r.map(c=>'"'+String(c??'').replace(/"/g,'""')+'"').join(',')).join('\n')],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='orders.csv';a.click()}
document.addEventListener('DOMContentLoaded',async()=>{
  if(!await guard())return;load();
  document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));
  $('logout').onclick=async()=>{await sb.auth.signOut();location.href='admin-login.html'};
  $('addBtn').onclick=()=>openProd(null);$('pForm').addEventListener('submit',saveProd);$('csvBtn').onclick=csv;
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('.modal').classList.remove('open'));
  document.addEventListener('click',async e=>{const t=e.target;
    if(t.dataset.edit)openProd(products.find(p=>p.id===t.dataset.edit));
    if(t.dataset.del&&confirm('Delete this product?')){const r=await sb.from('products').delete().eq('id',t.dataset.del);r.error?alert(r.error.message):(toast('Deleted'),load())}
    if(t.dataset.odel&&confirm('Delete this order?')){const r=await sb.from('orders').delete().eq('id',t.dataset.odel);r.error?alert(r.error.message):(toast('Deleted'),load())}
    if(t.dataset.view){const o=orders.find(x=>x.id===t.dataset.view);$('oDetail').innerHTML=`<p><b>${E(o.order_number)}</b> · ${new Date(o.created_at).toLocaleString()}</p><p>${E(o.customer_name)} · ${E(o.customer_phone)} · ${E(o.customer_email)}</p><p>${E(o.address)}, ${E(o.city)}, ${E(o.region)}</p>
      <ul>${(o.items||[]).map(i=>`<li>${E(i.name)} × ${i.qty} — ${M(i.price*i.qty)}</li>`).join('')}</ul><p>Subtotal ${M(o.subtotal)} · Delivery ${M(o.delivery_fee)} · <b>Total ${M(o.total)}</b></p><p>Payment: ${E(o.payment_status)} (${E(o.paystack_reference)}) · Status: ${E(o.order_status)}</p>`;
      $('markBtn').dataset.id=o.id;$('om').classList.add('open')}
    if(t.id==='markBtn'){const r=await sb.from('orders').update({order_status:'completed'}).eq('id',t.dataset.id);r.error?alert(r.error.message):($('om').classList.remove('open'),toast('Marked completed'),load())}
  });
});
})();
