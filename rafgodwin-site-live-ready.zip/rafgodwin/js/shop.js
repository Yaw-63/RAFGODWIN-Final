/* Shop listing + single product logic (needs supabase.js, cart.js) */
(function(){
const stars=(id)=>{const n=4+(String(id).split('').reduce((a,c)=>a+c.charCodeAt(0),0)%2);return '★'.repeat(n)+'☆'.repeat(5-n)};
const cardHTML=(p)=>`<article class="card">${p.badge?`<span class="badge">${RG.esc(p.badge)}</span>`:''}
 <a class="im" href="product.html?id=${encodeURIComponent(p.id)}"><img loading="lazy" src="${RG.esc(p.image_url)}" alt="${RG.esc(p.name)}"></a>
 <div class="bd"><span class="cat">${RG.esc(p.category)}</span><h3><a href="product.html?id=${encodeURIComponent(p.id)}">${RG.esc(p.name)}</a></h3>
 <div class="stars" aria-label="Rated">${stars(p.id)}</div>
 <div class="price">${RG.money(p.price)}${p.old_price?`<s>${RG.money(p.old_price)}</s>`:''}</div>
 ${p.stock<=0?'<div class="oos">Out of stock</div>':''}
 <div class="acts"><button class="btn btn-outline" data-add="${RG.esc(p.id)}" ${p.stock<=0?'disabled':''}>Add to Cart</button><button class="btn btn-primary" data-buy="${RG.esc(p.id)}" ${p.stock<=0?'disabled':''}>Buy Now</button></div></div></article>`;
let ALL=[];
const byId=id=>ALL.find(p=>String(p.id)===String(id));
document.addEventListener('click',e=>{
  const a=e.target.closest('[data-add]'),b=e.target.closest('[data-buy]');
  if(a){const p=byId(a.dataset.add);if(p)Cart.add(p,+(document.getElementById('pdQty')?.value||1)||1)}
  if(b){const p=byId(b.dataset.buy);if(p){Cart.add(p,+(document.getElementById('pdQty')?.value||1)||1);Cart.close();location.href='checkout.html'}}
});
async function initShop(){
  const grid=document.getElementById('grid');ALL=await RG.products();
  let cat='all';const q=document.getElementById('q'),sort=document.getElementById('sort');
  const draw=()=>{let l=ALL.filter(p=>(cat==='all'||p.category===cat)&&(p.name+' '+(p.description||'')).toLowerCase().includes(q.value.trim().toLowerCase()));
    if(sort.value==='lo')l.sort((a,b)=>a.price-b.price);if(sort.value==='hi')l.sort((a,b)=>b.price-a.price);
    grid.innerHTML=l.length?l.map(cardHTML).join(''):'<p class="empty" style="grid-column:1/-1">No products found.</p>';
    document.getElementById('count').textContent=l.length+' product'+(l.length===1?'':'s')};
  q.addEventListener('input',draw);sort.addEventListener('change',draw);
  document.querySelectorAll('.chips button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.chips button').forEach(x=>x.classList.remove('on'));b.classList.add('on');cat=b.dataset.c;draw()}));
  if(!window.sb)document.getElementById('demoNote').hidden=false;
  const pre=new URLSearchParams(location.search).get('cat');if(pre){const b=document.querySelector(`.chips button[data-c="${pre}"]`);if(b)b.click()}
  draw();
}
async function initProduct(){
  const id=new URLSearchParams(location.search).get('id'),box=document.getElementById('pd');
  const p=await RG.product(id);ALL=await RG.products();
  if(!p){box.innerHTML='<p class="empty">Product not found. <a href="shop.html">Back to shop</a></p>';return}
  document.title=p.name+' | RafGodwin Shop';
  /* SEO: per-product canonical, description and Product schema (Google renders this) */
  try{const head=document.head,add=(t,at)=>{const e=document.createElement(t);for(const k in at)e.setAttribute(k,at[k]);head.appendChild(e);return e},
    url=location.origin+'/product.html?id='+encodeURIComponent(p.id),d=(p.description||p.name).slice(0,160);
    head.querySelectorAll('link[rel=canonical],meta[name=description]').forEach(e=>e.remove());
    add('link',{rel:'canonical',href:url});add('meta',{name:'description',content:d+' Buy online from RafGodwin Engineering, Accra. Delivery across Ghana.'});
    add('meta',{property:'og:title',content:p.name+' | RafGodwin Shop'});add('meta',{property:'og:url',content:url});if(p.image_url)add('meta',{property:'og:image',content:p.image_url});
    const ld=add('script',{type:'application/ld+json'});
    ld.textContent=JSON.stringify({'@context':'https://schema.org','@type':'Product',name:p.name,description:p.description||p.name,image:p.image_url,category:p.category,brand:{'@type':'Brand',name:'RafGodwin Engineering'},
      offers:{'@type':'Offer',url,priceCurrency:'GHS',price:String(p.price),availability:p.stock>0?'https://schema.org/InStock':'https://schema.org/OutOfStock',seller:{'@type':'Organization',name:'RafGodwin Engineering'}}})}catch(e){}
  box.innerHTML=`<div class="pimg"><img src="${RG.esc(p.image_url)}" alt="${RG.esc(p.name)}"></div>
   <div><span class="cat">${RG.esc(p.category)}</span><h1>${RG.esc(p.name)}</h1><div class="stars">${stars(p.id)}</div>
   <div class="price">${RG.money(p.price)}${p.old_price?`<s>${RG.money(p.old_price)}</s>`:''}</div>
   <p class="desc">${RG.esc(p.description)}</p><p>${p.stock>0?'<span style="color:#7AC74F">In stock ('+p.stock+')</span>':'<span class="oos">Out of stock</span>'}</p>
   <div class="fld" style="max-width:120px"><label for="pdQty">Quantity</label><input id="pdQty" type="number" min="1" max="${Math.max(1,p.stock)}" value="1"></div>
   <div class="acts" style="max-width:420px"><button class="btn btn-outline" data-add="${RG.esc(p.id)}" ${p.stock<=0?'disabled':''}>Add to Cart</button><button class="btn btn-primary" data-buy="${RG.esc(p.id)}" ${p.stock<=0?'disabled':''}>Buy Now</button></div></div>`;
  const rel=ALL.filter(x=>x.category===p.category&&x.id!==p.id).slice(0,4);
  document.getElementById('related').innerHTML=rel.map(cardHTML).join('');
}
document.addEventListener('DOMContentLoaded',()=>{if(document.getElementById('grid'))initShop();if(document.getElementById('pd'))initProduct()});
})();
