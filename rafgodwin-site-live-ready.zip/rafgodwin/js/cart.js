/* RafGodwin cart: localStorage [{id,name,price,image,qty}], header badge, slide-out mini cart, cart.html table */
(function(){
const KEY='rg_cart';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'GHS '+Number(n||0).toLocaleString('en-GH',{maximumFractionDigits:2});
const Cart={
  get(){try{return JSON.parse(localStorage.getItem(KEY))||[]}catch(e){return[]}},
  save(c){try{localStorage.setItem(KEY,JSON.stringify(c))}catch(e){} Cart.render()},
  add(p,qty=1){const c=Cart.get(),i=c.find(x=>x.id===p.id);
    if(i)i.qty+=qty;else c.push({id:p.id,name:p.name,price:+p.price,image:p.image_url||p.image,qty});
    Cart.save(c);Cart.open()},
  setQty(id,q){let c=Cart.get();c=c.map(x=>x.id===id?{...x,qty:Math.max(1,q)}:x);Cart.save(c)},
  remove(id){Cart.save(Cart.get().filter(x=>x.id!==id))},
  clear(){Cart.save([])},
  count(){return Cart.get().reduce((a,x)=>a+x.qty,0)},
  subtotal(){return Cart.get().reduce((a,x)=>a+x.qty*x.price,0)},
  open(){const d=document.getElementById('miniCart');if(d){d.classList.add('open');document.getElementById('miniOv').classList.add('open')}},
  close(){const d=document.getElementById('miniCart');if(d){d.classList.remove('open');document.getElementById('miniOv').classList.remove('open')}},
  render(){
    document.querySelectorAll('.cart-badge').forEach(b=>{const n=Cart.count();b.textContent=n;b.hidden=!n});
    const body=document.getElementById('miniBody');
    if(body){const c=Cart.get();
      body.innerHTML=c.length?c.map(x=>`<div class="mini-item"><img src="${esc(x.image)}" alt=""><div><b>${esc(x.name)}</b><div class="mi-p">${money(x.price)}</div>
        <div class="qty"><button data-q="${esc(x.id)}" data-d="-1">&minus;</button><span>${x.qty}</span><button data-q="${esc(x.id)}" data-d="1">+</button></div></div>
        <button class="mi-x" data-rm="${esc(x.id)}" aria-label="Remove">&times;</button></div>`).join(''):'<p class="empty">Your cart is empty.</p>';
      document.getElementById('miniTotal').textContent=money(Cart.subtotal())}
    const t=document.getElementById('cartRows');
    if(t){const c=Cart.get();document.getElementById('cartEmpty').hidden=!!c.length;document.getElementById('cartFull').hidden=!c.length;
      t.innerHTML=c.map(x=>`<tr><td data-l="Product"><div class="ct-prod"><img src="${esc(x.image)}" alt=""><b>${esc(x.name)}</b></div></td><td data-l="Price">${money(x.price)}</td>
        <td data-l="Qty"><div class="qty"><button data-q="${esc(x.id)}" data-d="-1">&minus;</button><span>${x.qty}</span><button data-q="${esc(x.id)}" data-d="1">+</button></div></td>
        <td data-l="Total">${money(x.price*x.qty)}</td><td><button class="mi-x" data-rm="${esc(x.id)}" aria-label="Remove">&times;</button></td></tr>`).join('');
      document.getElementById('cSub').textContent=money(Cart.subtotal());
      const d=document.getElementById('cDel');if(d)d.textContent='Calculated at checkout';
      document.getElementById('cTot').textContent=money(Cart.subtotal())}
  }
};
window.Cart=Cart;
document.addEventListener('click',e=>{
  const q=e.target.closest('[data-q]'),r=e.target.closest('[data-rm]');
  if(q){const it=Cart.get().find(x=>x.id===q.dataset.q);if(it)Cart.setQty(it.id,it.qty+ +q.dataset.d)}
  if(r)Cart.remove(r.dataset.rm);
  if(e.target.closest('.cart-btn[data-mini]')){e.preventDefault();Cart.open()}
  if(e.target.id==='miniOv'||e.target.closest('#miniClose'))Cart.close();
});
document.addEventListener('DOMContentLoaded',()=>{
  if(document.body.dataset.mini!==undefined){
    document.body.insertAdjacentHTML('beforeend',`<div id="miniOv" class="mini-ov"></div><aside id="miniCart" class="mini-cart" aria-label="Cart"><div class="mc-h"><h3>Your Cart</h3><button id="miniClose" class="mi-x" aria-label="Close">&times;</button></div><div id="miniBody" class="mc-b"></div><div class="mc-f"><div class="mc-t"><span>Subtotal</span><b id="miniTotal"></b></div><a class="btn btn-primary" href="checkout.html">Checkout</a><a class="btn btn-outline" href="cart.html">View Cart</a></div></aside>`);
    document.querySelectorAll('.cart-btn').forEach(b=>b.dataset.mini='1')}
  Cart.render();
});
window.addEventListener('storage',()=>Cart.render());
})();
