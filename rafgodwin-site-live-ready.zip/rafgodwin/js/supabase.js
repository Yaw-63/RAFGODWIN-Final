/* RafGodwin Shop - Supabase config. PASTE YOUR VALUES BELOW (see SUPABASE_SETUP.md) */
const SUPABASE_URL = 'https://alyawzrwuphalpfplplh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFseWF3enJ3dXBoYWxwZnBscGxoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMyMTI5NDcsImV4cCI6MjEwODc4ODk0N30.OFwF5TF43V_2CJQPl5q5Yy4bPstdVOlexL0v2bmhUMY';
const PAYSTACK_PUBLIC_KEY = 'pk_test_xxxx'; // used by js/paystack.js

const RG_CONFIGURED = !/YOUR_SUPABASE_URL/.test(SUPABASE_URL) && !/YOUR_ANON_KEY/.test(SUPABASE_ANON_KEY);
window.sb = (RG_CONFIGURED && window.supabase) ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const U = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=700&q=70`;
/* Demo catalogue: shown until Supabase is connected. Same items as the SQL seed. */
const DEMO_PRODUCTS = [
 ['Smart WiFi Wall Switch 1-Gang','Smart Home',250,300,40,'Touch WiFi switch, works with Alexa & Google, app control.','photo-1558002038-1055907df827','New'],
 ['Smart WiFi Wall Switch 2-Gang','Smart Home',320,380,35,'Two-gang touch switch with timers and scenes.','photo-1558002038-1055907df827',''],
 ['Smart WiFi Wall Switch 3-Gang','Smart Home',380,null,30,'Three-gang smart switch, neutral wire required.','photo-1558002038-1055907df827','Popular'],
 ['Smart Plug 16A with Energy Monitor','Smart Home',180,220,60,'Control and track power use of any appliance.','photo-1585771724684-38269d6639fd',''],
 ['Smart Video Doorbell','Smart Home',650,800,20,'1080p doorbell with two-way audio and motion alerts.','photo-1558002038-1055907df827','Sale'],
 ['Smart Home Hub Gateway','Smart Home',420,null,25,'Zigbee/Bluetooth gateway connecting all your devices.','photo-1558089687-f282ffcbc126',''],
 ['4-Camera CCTV Kit (1080p)','Security',2500,2900,12,'4 cameras, 4-channel DVR, 1TB HDD and cables.','photo-1557324232-b8917d3c3dcb','Best Seller'],
 ['8-Camera CCTV Kit (2MP)','Security',3600,4000,8,'8 cameras, 8-channel DVR, 2TB HDD, night vision.','photo-1557324232-b8917d3c3dcb',''],
 ['8-Camera Colour Night CCTV Kit','Security',4200,null,6,'Full-colour night vision, remote phone viewing.','photo-1557324232-b8917d3c3dcb','Premium'],
 ['Solar WiFi Security Camera','Security',780,950,22,'Wire-free outdoor camera with solar panel.','photo-1580894732444-8ecded7900cd',''],
 ['Fingerprint Smart Door Lock','Security',1450,1700,15,'Fingerprint, PIN, card and key access.','photo-1558002038-1055907df827','Popular'],
 ['Electric Fence Energizer 10km','Security',1900,null,10,'Perimeter energizer with alarm output and keypad.','photo-1558002038-1055907df827',''],
 ['Solar Panel 200W Mono','Solar',1100,1250,30,'High-efficiency monocrystalline panel.','photo-1509391366360-2e959784a276',''],
 ['Solar Panel 450W Mono','Solar',1800,2000,18,'Heavy-duty 450W panel for home systems.','photo-1509391366360-2e959784a276','Best Seller'],
 ['Hybrid Inverter 3.5kVA','Solar',2200,2500,10,'3.5kVA hybrid inverter with built-in MPPT.','photo-1558449028-b53a39d100fc',''],
 ['Hybrid Inverter 5kVA','Solar',3900,4300,8,'5kVA hybrid, WiFi monitoring, 48V.','photo-1558449028-b53a39d100fc','Popular'],
 ['Hybrid Inverter 10kVA','Solar',6500,null,4,'10kVA three-phase ready hybrid inverter.','photo-1558449028-b53a39d100fc','Premium'],
 ['Lithium Battery 5kWh 48V','Solar',5800,6400,7,'LiFePO4 rack battery, 6000+ cycles.','photo-1620714223084-8fcacc6dfd8d',''],
 ['Gel Battery 200Ah 12V','Solar',2100,2400,14,'Deep-cycle gel battery for solar storage.','photo-1620714223084-8fcacc6dfd8d',''],
 ['MPPT Solar Charge Controller 60A','Solar',650,780,25,'60A MPPT controller with LCD display.','photo-1558449028-b53a39d100fc','']
].map((p,i)=>({id:'demo-'+(i+1),name:p[0],slug:p[0].toLowerCase().replace(/[^a-z0-9]+/g,'-'),category:p[1],price:p[2],old_price:p[3],stock:p[4],description:p[5],image_url:U(p[6]),badge:p[7],featured:i%4===0,created_at:new Date(Date.now()-i*864e5).toISOString()}));

const RG = {
  money:(n)=>'GHS '+Number(n||0).toLocaleString('en-GH',{minimumFractionDigits:0,maximumFractionDigits:2}),
  esc:(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
  async products(){
    if(!sb) return DEMO_PRODUCTS;
    const {data,error}=await sb.from('products').select('*').order('created_at',{ascending:false});
    if(error){console.error(error);return DEMO_PRODUCTS}
    return data;
  },
  async product(id){
    if(!sb||String(id).startsWith('demo-')) return DEMO_PRODUCTS.find(p=>p.id===id)||null;
    const {data}=await sb.from('products').select('*').eq('id',id).single();
    return data||null;
  }
};
