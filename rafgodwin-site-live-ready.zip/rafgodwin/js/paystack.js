/* Checkout + Paystack Inline (needs supabase.js, cart.js) */
(function(){
const REGIONS={'Greater Accra':50,'Central':120,'Eastern':120,'Volta':150,'Ashanti':150,'Western':180,'Western North':200,'Oti':200,'Bono':200,'Bono East':220,'Ahafo':220,'Northern':280,'Savannah':300,'North East':300,'Upper East':300,'Upper West':300};
const $=id=>document.getElementById(id);
let fee=0;
function totals(){const sub=Cart.subtotal();const del=document.querySelector('input[name=ship]:checked').value==='pickup'?0:(REGIONS[$('region').value]||0);fee=del;
  $('sSub').textContent=RG.money(sub);$('sDel').textContent=del?RG.money(del):'Free';$('sTot').textContent=RG.money(sub+del);return{sub,del,total:sub+del}}
function draw(){const c=Cart.get();if(!c.length){location.href='cart.html';return}
  $('sItems').innerHTML=c.map(x=>`<div><span>${RG.esc(x.name)} × ${x.qty}</span><span>${RG.money(x.price*x.qty)}</span></div>`).join('');totals()}
function payRef(){return 'RFG'+Date.now().toString(36).toUpperCase()+Math.floor(Math.random()*9000+1000)}
function orderNo(){return 'RFG-'+Date.now().toString(36).toUpperCase().slice(-5)+Math.floor(Math.random()*90+10)}
async function saveOrder(ref,t){
  const o={order_number:orderNo(),customer_name:$('name').value.trim(),customer_phone:$('phone').value.trim(),customer_email:$('email').value.trim(),region:$('region').value,city:$('city').value.trim(),address:$('address').value.trim(),
    items:Cart.get().map(x=>({id:x.id,name:x.name,price:x.price,qty:x.qty,image:x.image})),subtotal:t.sub,delivery_fee:t.del,total:t.total,payment_method:'Paystack (MoMo/Card)',payment_status:'paid',order_status:'pending',paystack_reference:ref};
  if(window.sb){const {error}=await sb.from('orders').insert(o);if(error){console.error(error);alert('Payment received but saving order failed. Keep this reference: '+ref+' and call us.');}
    else await sb.rpc('decrement_stock',{items:o.items.filter(i=>!String(i.id).startsWith('demo-')).map(i=>({id:i.id,qty:i.qty}))})}
  return o.order_number}
document.addEventListener('DOMContentLoaded',()=>{
  if(!$('payBtn'))return;
  $('region').innerHTML='<option value="">Select region</option>'+Object.keys(REGIONS).sort().map(r=>`<option>${r}</option>`).join('');
  draw();document.querySelectorAll('input[name=ship]').forEach(r=>r.addEventListener('change',totals));$('region').addEventListener('change',totals);
  $('payBtn').addEventListener('click',()=>{
    const f=$('ckForm');if(!f.reportValidity())return;
    if(!/^(\+?233|0)\d{9}$/.test($('phone').value.replace(/\s/g,''))){alert('Enter a valid Ghana phone number, e.g. 024 711 7982');return}
    const t=totals();
    if(!window.PaystackPop){alert('Payment script failed to load. Check your connection.');return}
    const ref=payRef(),ship=document.querySelector('input[name=ship]:checked').value;
    /* Only ids and quantities are sent: the server re-prices everything from the database and checks the amount paid. */
    const order={items:Cart.get().map(x=>({id:x.id,qty:x.qty})),ship,region:$('region').value,city:$('city').value.trim(),address:$('address').value.trim(),name:$('name').value.trim(),phone:$('phone').value.trim(),email:$('email').value.trim()};
    PaystackPop.setup({key:PAYSTACK_PUBLIC_KEY,ref,email:$('email').value.trim(),amount:Math.round(t.total*100),currency:'GHS',channels:['mobile_money','card'],
      metadata:{order,custom_fields:[{display_name:'Customer',variable_name:'customer',value:$('name').value},{display_name:'Phone',variable_name:'phone',value:$('phone').value}]},
      callback:function(res){$('payBtn').disabled=true;$('payBtn').textContent='Confirming payment…';
        if(!window.sb){saveOrder(res.reference,t).then(n=>{Cart.clear();location.href='order-success.html?order='+encodeURIComponent(n)});return}
        /* live mode: the server confirms the payment with Paystack and saves the order */
        fetch('/.netlify/functions/verify-payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reference:res.reference})})
          .then(r=>r.json().catch(()=>({}))).then(j=>{Cart.clear();location.href='order-success.html?'+(j&&j.order_number?'order='+encodeURIComponent(j.order_number):'ref='+encodeURIComponent(res.reference))})
          .catch(()=>{Cart.clear();location.href='order-success.html?ref='+encodeURIComponent(res.reference)})},
      onClose:function(){}}).openIframe();
  });
});
})();
