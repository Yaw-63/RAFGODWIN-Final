/* /sitemap-products.xml : one entry per shop product, always current. (Static pages are in sitemap.xml.) */
const { sb, sbHeaders } = require('./_shared');
exports.handler = async (event) => {
  const host = (event.headers['x-forwarded-host'] || event.headers.host || 'rafgodwin.com').split(',')[0].trim();
  const base = 'https://' + host;
  let list = [];
  try {
    const r = await sb('products?select=id,created_at&order=created_at.desc&limit=5000', { headers: sbHeaders() });
    list = (r.ok && r.data) || [];
  } catch (e) {}
  const xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    list.map(p => '<url><loc>' + base + '/product.html?id=' + encodeURIComponent(p.id) + '</loc><lastmod>' + String(p.created_at || '').slice(0, 10) + '</lastmod></url>').join('\n') + '\n</urlset>\n';
  return { statusCode: 200, headers: { 'Content-Type': 'application/xml', 'Cache-Control': 'public, max-age=3600' }, body: xml };
};
