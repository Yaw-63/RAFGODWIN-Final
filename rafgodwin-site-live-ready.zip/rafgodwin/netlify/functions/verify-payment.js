/* Called by the checkout page after Paystack reports success. Confirms the payment server-side, then saves the order. */
const { finalizeOrder, json } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, error: 'Method not allowed' });
  let reference = '';
  try { reference = JSON.parse(event.body || '{}').reference; } catch (e) {}
  if (!/^[\w.-]{6,100}$/.test(reference || '')) return json(400, { ok: false, error: 'Bad reference' });
  try {
    const o = await finalizeOrder(reference);
    return json(200, { ok: true, order_number: o.order_number, status: o.payment_status });
  } catch (e) {
    return json(e.status || 500, { ok: false, error: e.message });
  }
};
