/* Paystack calls this itself when a payment succeeds, so an order is still saved if the customer closes the tab.
   Set the URL in Paystack: Settings > API Keys & Webhooks > Live Webhook URL = https://YOURDOMAIN/.netlify/functions/paystack-webhook */
const { crypto, finalizeOrder, PS_KEY } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: '' };
  const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
  const sig = event.headers['x-paystack-signature'] || event.headers['X-Paystack-Signature'] || '';
  if (!PS_KEY()) return { statusCode: 500, body: 'not configured' };
  const expected = crypto.createHmac('sha512', PS_KEY()).update(raw).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(String(sig));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { statusCode: 401, body: 'bad signature' };
  let ev; try { ev = JSON.parse(raw); } catch (e) { return { statusCode: 400, body: 'bad json' }; }
  if (ev.event !== 'charge.success' || !ev.data || !ev.data.reference) return { statusCode: 200, body: 'ignored' };
  try {
    await finalizeOrder(ev.data.reference);
    return { statusCode: 200, body: 'ok' };
  } catch (e) {
    if (e.status === 422) return { statusCode: 200, body: 'not a shop order' }; /* e.g. a payment made outside the shop: do not retry */
    return { statusCode: 500, body: 'retry' }; /* Paystack retries on non-200 */
  }
};
