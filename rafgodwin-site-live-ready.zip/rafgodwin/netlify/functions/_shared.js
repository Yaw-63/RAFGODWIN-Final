/* Shared helpers for the Paystack functions. No dependencies (uses Node's built-in fetch + crypto). */
const crypto = require('crypto');

/* Keep in sync with REGIONS in js/paystack.js and assets/js/main.js */
const REGIONS = {'Greater Accra':50,'Central':120,'Eastern':120,'Volta':150,'Ashanti':150,'Western':180,'Western North':200,'Oti':200,'Bono':200,'Bono East':220,'Ahafo':220,'Northern':280,'Savannah':300,'North East':300,'Upper East':300,'Upper West':300};

const SB_URL = () => (process.env.SUPABASE_URL || 'https://alyawzrwuphalpfplplh.supabase.co').replace(/\/$/, '');
const SB_KEY = () => process.env.SUPABASE_SERVICE_ROLE_KEY;
const PS_KEY = () => process.env.PAYSTACK_SECRET_KEY;

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

const sbHeaders = (extra) => Object.assign({ apikey: SB_KEY(), Authorization: 'Bearer ' + SB_KEY(), 'Content-Type': 'application/json' }, extra || {});
async function sb(path, opts) {
  const r = await fetch(SB_URL() + '/rest/v1/' + path, opts);
  const t = await r.text();
  let j = null; try { j = t ? JSON.parse(t) : null; } catch (e) {}
  return { ok: r.ok, status: r.status, data: j };
}

const clean = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const orderNo = () => 'RFG-' + Date.now().toString(36).toUpperCase().slice(-5) + Math.floor(Math.random() * 90 + 10);

async function findByRef(reference) {
  const r = await sb('orders?paystack_reference=eq.' + encodeURIComponent(reference) + '&select=order_number,payment_status&limit=1', { headers: sbHeaders() });
  return r.ok && r.data && r.data[0] ? r.data[0] : null;
}

/* Verifies the payment with Paystack, re-prices the order from the database, and saves it once (safe to call repeatedly). */
async function finalizeOrder(reference) {
  if (!PS_KEY() || !SB_KEY()) throw new HttpError(500, 'Server is not configured (missing PAYSTACK_SECRET_KEY or SUPABASE_SERVICE_ROLE_KEY).');

  const existing = await findByRef(reference);
  if (existing) return existing;

  const pr = await fetch('https://api.paystack.co/transaction/verify/' + encodeURIComponent(reference), { headers: { Authorization: 'Bearer ' + PS_KEY() } });
  const pj = await pr.json().catch(() => ({}));
  if (!pr.ok || !pj.status || !pj.data) throw new HttpError(502, 'Could not verify payment with Paystack.');
  const tx = pj.data;
  if (tx.status !== 'success') throw new HttpError(402, 'Payment not successful.');
  if (tx.currency && tx.currency !== 'GHS') throw new HttpError(422, 'Unexpected currency.');

  const m = tx.metadata && tx.metadata.order;
  if (!m || !Array.isArray(m.items) || !m.items.length) throw new HttpError(422, 'Transaction has no order details.');

  const items = m.items.slice(0, 50).map(i => ({ id: String(i.id || ''), qty: Math.max(1, Math.min(1000, parseInt(i.qty, 10) || 1)) }));
  const ids = items.map(i => i.id).filter(id => UUID.test(id));
  let prods = [];
  if (ids.length) {
    const r = await sb('products?id=in.(' + ids.join(',') + ')&select=id,name,price,image_url', { headers: sbHeaders() });
    prods = (r.ok && r.data) || [];
  }
  const byId = {}; prods.forEach(p => { byId[p.id] = p; });

  let sub = 0, allFound = true;
  const lines = items.map(i => {
    const p = byId[i.id];
    if (!p) { allFound = false; return { id: i.id, name: 'Unknown product', price: 0, qty: i.qty }; }
    sub += Number(p.price) * i.qty;
    return { id: p.id, name: p.name, price: Number(p.price), qty: i.qty, image: p.image_url };
  });

  const pickup = m.ship === 'pickup';
  const region = clean(m.region, 60);
  const regionKnown = pickup || Object.prototype.hasOwnProperty.call(REGIONS, region);
  const fee = pickup ? 0 : (REGIONS[region] || 0);
  const expected = Math.round((sub + fee) * 100);
  /* 'paid' only if what was charged equals the real price of the items + delivery; otherwise flagged for a human to check */
  const status = (allFound && regionKnown && expected === tx.amount) ? 'paid' : 'review';

  const order = {
    order_number: orderNo(),
    customer_name: clean(m.name, 120), customer_phone: clean(m.phone, 40), customer_email: clean(m.email || (tx.customer && tx.customer.email), 160),
    region: pickup ? 'Pickup' : region, city: clean(m.city, 80), address: pickup ? 'Pickup at Sowutoum office' : clean(m.address, 300),
    items: lines, subtotal: sub, delivery_fee: fee, total: tx.amount / 100,
    payment_method: 'Paystack (' + (tx.channel || 'MoMo/Card') + ')', payment_status: status, order_status: 'pending', paystack_reference: reference
  };

  const ins = await sb('orders', { method: 'POST', headers: sbHeaders({ Prefer: 'return=minimal' }), body: JSON.stringify(order) });
  if (!ins.ok) {
    const again = await findByRef(reference); /* the webhook and the browser can race: the unique index makes one of them lose */
    if (again) return again;
    throw new HttpError(500, 'Could not save order.');
  }
  if (status === 'paid') {
    const real = lines.filter(l => UUID.test(l.id) && byId[l.id]).map(l => ({ id: l.id, qty: l.qty }));
    if (real.length) await sb('rpc/decrement_stock', { method: 'POST', headers: sbHeaders(), body: JSON.stringify({ items: real }) });
  }
  return { order_number: order.order_number, payment_status: status };
}

const json = (status, body) => ({ statusCode: status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) });
module.exports = { crypto, REGIONS, HttpError, finalizeOrder, json, sb, sbHeaders, SB_URL, PS_KEY };
